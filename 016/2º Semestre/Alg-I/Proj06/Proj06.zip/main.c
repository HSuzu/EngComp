#include<stdio.h>
#include<stdlib.h>
#include "avl.h"

int main() {
  AVL a;
  cria(&a);

  int in;
  while(fscanf(stdin, "%d", &in) == 1) {
    inserir(&a, &in);
  }

  fprintf(stdout, "%d\n", isAVL(a.raiz));
  delete(a.raiz);
  return 0;
}
